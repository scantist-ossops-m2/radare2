/* radare2 - LGPL - Copyright 2013-2019 - pancake */

#include <r_main.h>

int main(int argc, const char **argv) {
	return r_main_r2agent (argc, argv);
}
