/* radare - LGPL - Copyright 2009-2019 - pancake */

#include <r_main.h>

int main (int argc, const char *argv[]) {
	return r_main_radiff2 (argc, argv);
}
