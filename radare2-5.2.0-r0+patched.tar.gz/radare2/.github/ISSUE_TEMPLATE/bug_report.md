---
name: Bug report
about: Create a report to help us improve

---

## Environment

```sh
# copypaste this script into your shell and replace it with the output
date
r2 -v
uname -ms
```

## Description

<!-- Explain what's the issue and what would you expect to see -->

## Test

<!-- Steps to reproduce the issue and provide files/links/images/.. -->
