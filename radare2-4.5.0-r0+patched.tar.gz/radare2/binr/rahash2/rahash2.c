/* radare - LGPL - Copyright 2009-2020 - pancake */

#include <r_main.h>

int main(int argc, const char **argv) {
	return r_main_rahash2(argc, argv);
}
