/* radare2 - Copyleft 2011-2019 - pancake */

#include <r_main.h>

int main(int argc, const char **argv) {
	return r_main_rarun2 (argc, argv);
}
