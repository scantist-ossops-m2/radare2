/* radare - LGPL - Copyright 2021 - pancake */
#include <r_main.h>

int main (int argc, const char *argv[]) {
	return r_main_ravc2 (argc, argv);
}
