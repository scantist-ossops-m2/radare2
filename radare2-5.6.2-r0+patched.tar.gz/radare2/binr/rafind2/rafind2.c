/* radare - LGPL - Copyright 2009-2021 - pancake */

#include <r_main.h>

int main(int argc, const char **argv) {
	return r_main_rafind2 (argc, argv);
}

