---
name: Feature request
about: Suggest an idea for this project

---

## Description

*Please describe what are you missing or wanting to be improved*

*Provide images, ascii-art, test files and anything that may help us understand your request*
