/* radare - LGPL - Copyright 2007-2019 - pancake */

#include <r_main.h>

int main(int argc, const char **argv) {
	return r_main_ragg2 (argc, argv);
}
