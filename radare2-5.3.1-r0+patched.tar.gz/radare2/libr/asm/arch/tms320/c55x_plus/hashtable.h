#ifndef HASHTABLE_H
#define HASHTABLE_H

st32 get_hash_code(ut32 ins_pos);

#endif
