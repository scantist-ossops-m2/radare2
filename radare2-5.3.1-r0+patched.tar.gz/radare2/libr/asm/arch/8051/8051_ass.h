#ifndef _8051_ASS_H
#define _8051_ASS_H

#include<r_asm.h>
int assemble_8051(RAsm *a, RAsmOp *op, char const *user_asm);

#endif
